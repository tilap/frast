#### Browserify

If you often use the same components and they are not in bower, include them fast with browserify.

Or code clean by separating you javascript features and take advantage of javascript require function.
                