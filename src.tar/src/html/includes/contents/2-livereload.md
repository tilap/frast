**Frast** comes with html, javascript and less compilation. But you don't loose time asking for compilation everytime nor refreshing  your browser.

**Frast** watchs any change on your files. When you save a file, **Frast** compiles and refresh the changes on your browser. Moreover, **Frast** only reloads what's needed: you change a less file, only the CSS will be live reloaded.

You see what you code in realtime, adjust quickly your code to get what you aim to.