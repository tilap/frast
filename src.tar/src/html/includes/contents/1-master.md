All tools are integrated to make you work fast with a default optimized config. But you can easily turn anything on/off or custom any of their options. 

You have not to adopt **Frast**. **Frast** adapts to your needs. If it fails, fork it to break it! Or ask us to improve it.