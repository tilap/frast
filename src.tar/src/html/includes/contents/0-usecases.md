#### Usecases

**Frast** is perfect for:

- static html page buidling ;
- html mockup ;
- test frontend concept/UI and ideas ;
- github.io page creation.

_For example, this page is built with Frast :)_