#### Customize your fonticon fast, **Frast** comes with the Fontello UI editor.

**Frast** comes with fontello automation. Open your current frast project fonticon, edit it in fontello GUI, add, edit, custom, save, and they are available in your project.

If you have no fonticon coz your not a designer, you can access all the fonticon preset easily.