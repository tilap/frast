#### Html and Markdown

Thanks to gulp plugins, **Frast** allows to include external html or markdown files (wich of course are parsed on compilation).

Thus you can easily put your customer contents. Or reuse the same files in many places, on many pages.