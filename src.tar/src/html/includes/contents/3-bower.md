#### Bower

**Frast** comes with bower. It installs bower locally, so you don't need to install it globally on your computer or bother about the version.

Updating the _bower.json_ file, you can add thousands of frontend library fast, no matter of dependancies.