**Frast** is built over gulp and comes with awesome services and best practices. It has been developped, keeping in mind the "Keep It Simple Stupid" adage.

All your source codes are checked, optimized, compiled and served throught a light micro-server. You can access the result on your browser, update your work easily, and publish it on github.io in a minute.