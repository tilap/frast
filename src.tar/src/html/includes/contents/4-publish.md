Once you're happy with your webpages, you can publish it on [github.io](http://github.io).

**Frast** will be clean, compil again to keep sure everything is good and push on the gh-pages of your repo. Your website will be available on http://username.github.io/repositoryname/

As **Frast** optimize html, css, javascript, images, ... the page will look really good and load fast.

By changing the configuration, you can push you static page on any other repository/branch.