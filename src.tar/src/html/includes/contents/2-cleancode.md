While coding fast, you sometimes do mistake in your code: bad html tagging, error in you javascript file, ... 

> "*Errare humanum est, perseverare diabolicum*"

**Frast** provides live linting on compilation and checks the code of any file you save. If there is an error, you'll know it instantly with a smart desktop notification. Clean code has never been so easy.

