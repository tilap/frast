#### Don't be shame using small images, Frast build your sprite.

If you need lots of small images, you'll probably want to use sprites. **Frast** comes with a task generating your sprite automaticall and the LessCss class to use it.

Just drop your images in a the sprite project folder, and use the css class.