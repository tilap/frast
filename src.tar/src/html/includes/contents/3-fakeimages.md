
#### Put real images, no placeholders.

While you're coding a mockup or some frontend test, you often need images but you don't have time finding, croping, resizing somes that won't be kept.

**Frast** comes with a easy-to-use helper you can put anywhere in your html to insert a random image. For example, write that in your html file: